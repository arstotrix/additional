__author__ = 'liza55'

import codecs, os
from nltk.tokenize import RegexpTokenizer
#from nltk.tokenize.util import regexp_span_tokenize as sp
tokenizer = RegexpTokenizer('\w+|\$[\d\.]+|\S+')

d = os.getcwd()
f = os.listdir(d)
txt = [x for x in f if x.endswith('.txt') and not x.endswith('.token.txt')]
for t in txt:
    source = codecs.open(t, 'r', 'utf-8')
    stri = source.read()
    new = codecs.open(t[:-4] + '.token.txt', 'w', 'utf-8')
    ann = codecs.open(t[:-4] + '.ann', 'w', 'utf-8')
    tok = tokenizer.tokenize(stri)
    spans = []
    for token in tok:
        span = (stri.index(token), stri.index(token) + len(token))
        spans.append(span)
        stri = stri[:span[0]] + ' '*(span[1] - span[0]) + stri[span[1]:]
    #spans = [(stri.index(token), stri.index(token) + len(token)) for token in tok]
    iden = 1
    for i in range(len(tok)):
        new.write(tok[i] + '\t' + str(spans[i][0]) + ' ' + str(spans[i][1]) + '\n')
        ann.write('T' + str(iden) + '\t' + 'suggestion ' + str(spans[i][0]) + ' ' + str(spans[i][1]) +
                  '\t' + tok[i] + '\n' + '#' + str(iden) + '\t' + 'AnnotatorNotes T' + str(iden) + '\thahaha!' + '\n')
        iden += 1
    new.close()
    ann.close()
    #spans = list(sp(stri, '\s+|[.,?;!]+(?![.,?;!])'))