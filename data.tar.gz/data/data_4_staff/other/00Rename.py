import codecs, os


counter = 765
directory = os.getcwd()
files = os.listdir(directory)
arguments = [x for x in files if x.endswith('.txt') or x.endswith('.ann')]
for fname in sorted(arguments):
    if fname.endswith('.ann'):
    #    ext = fname[-4:]
    #    dst = fname[:-4] 
    #    src = fname
    #    ext = fname[-4:]
    #    src = fname
    #    dst = src.split('-')[0] + ext
        print fname
        exts = ['.ann', '.txt']
        for ext in exts:
            src = fname[:-4] + ext
            #dst = 'esl_0' + str(counter) + ext
            #print 'src', src, 'dst', dst
            dst = src.replace('_', '_0')
	    if len(fname[:-4]) == 8:
        	os.rename(src, dst)
        counter += 1
