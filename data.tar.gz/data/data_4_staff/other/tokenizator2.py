import subprocess as sp
import codecs, os, re
from nltk.tokenize import RegexpTokenizer
#from nltk.tokenize.util import regexp_span_tokenize as sp
tokenizer = RegexpTokenizer('\w+|\$[\d\.]+|\S+')

def lemmatizer(x):
	lemmas = []
	tagged = sp.Popen([u'analyzer_client', u'40005'], stdin=sp.PIPE, stdout=sp.PIPE).communicate(x.encode('utf-8'))[0]
	tagged = tagged.strip().split('\n')
	#print tagged
	for word in tagged:
		
		word = word.split()
		if word:
			
		# and word[0] != ',' and word[0] != '.' and word[0] != '?' and word[0] != '!':
			lemmas.append(word[:-1])
	return lemmas


d = os.getcwd()
f = os.listdir(d)
txt = [x for x in f if x.endswith('.txt') and not x.endswith('.token.txt')]
for t in txt:
    source = codecs.open(t, 'r', 'utf-8')
    stri = source.read()
    freeling = lemmatizer(stri)
    #print freeling
    new = codecs.open(t[:-4] + '.token.txt', 'w', 'utf-8')
    ann = codecs.open(t[:-4] + '.ann', 'w', 'utf-8')
    tok = tokenizer.tokenize(stri)
    spans = []
    for token in tok:
        span = (stri.index(token), stri.index(token) + len(token))
        spans.append(span)
        stri = stri[:span[0]] + ' '*(span[1] - span[0]) + stri[span[1]:]
    #spans = [(stri.index(token), stri.index(token) + len(token)) for token in tok]
    iden = 1
    for i in range(len(tok)):
        new.write(tok[i] + '\t' + str(spans[i][0]) + ' ' + str(spans[i][1]) + '\n')
        ann.write('T' + str(iden) + '\t' + 'suggestion ' + str(spans[i][0]) + ' ' + str(spans[i][1]) +
                  '\t' + tok[i] + '\n' + '#' + str(iden) + '\t' + 'AnnotatorNotes T' + str(iden) + '\thahaha!' + '\n')
        iden += 1
    for i in range(len(tok)):
	if tok[i] == freeling[i][0]:
	    ann.write('T' + str(iden) + '\tpos_' + freeling[i][2] + ' ' + str(spans[i][0]) + ' ' + str(spans[i][1]) + 
		      '\t' + freeling[i][0] + '\n' + '#' + str(iden) + '\tAnnotatorNotes T' + str(iden) + '\tlemma = \'' +
		      freeling[i][1] + '\n') 
	    iden += 1
	else:
	    print tok[i], freeling[i][0]
	    corr = re.findall('_', freeling[i][0])
	    if len(corr) != 0:
		freeling = freeling[:i] + list(freeling[i])*(len(corr) - 1) + freeling[i:]
    new.close()
    ann.close()
#spans = list(sp(stri, '\s+|[.,?;!]+(?![.,?;!])'))