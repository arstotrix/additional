import codecs, re, os

for root, dirs, files in os.walk('.'):
    for f in files:
        if f.endswith('.ann') and not f.endswith('_new.ann'):
            print f
            old_ann = codecs.open(f, 'r', 'utf-8')
            lines = old_ann.readlines()
            old_ann.close()
            new_ann = codecs.open(f, 'w', 'utf-8')
            for line in lines:
                if line.startswith('T'):
                    line = re.sub('(T\\d*\t)([^\t]*)\t[^\n]*\n', '\\1\\2\n', line, flags = re.U|re.I)
                    new_ann.write(line)
                else:
                    new_ann.write(line)
            new_ann.close()
                    
