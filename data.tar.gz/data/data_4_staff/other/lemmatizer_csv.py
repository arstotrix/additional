#!/bin/python
# coding: utf-8
# Extracting lemmas of words with Freeling
# author: Andrey Kutuzov
# GPL v 3.0
from __future__ import division
import subprocess as sp
import codecs, os

def lemmatizer(x):
	lemmas = []
	tagged = sp.Popen([u'analyzer_client', u'40005'], stdin=sp.PIPE, stdout=sp.PIPE).communicate(x.encode('utf-8'))[0]
	tagged = tagged.strip().split('\n')
	#print tagged
	for word in tagged:
		word = word.split()
		if word:
		# and word[0] != ',' and word[0] != '.' and word[0] != '?' and word[0] != '!':
			lemmas.append(word[:-1])
	return lemmas

#f = codecs.open('esl_564.txt', 'r', 'utf-8')
#text = f.read()
#print lemmatizer('But in 2012 about 14% of obese people')
for root, dirs, files in os.walk('.'):
	for f in files:
		if f.endswith('.txt'):
			text_file = codecs.open(f, 'r', 'utf-8')
			text = text_file.read()
			freeling = codecs.open(f[:-4] + '.csv', 'w', 'utf-8')
			result_freeling = lemmatizer(text)
			for word_info in result_freeling:
				try:
					freeling.write(word_info[0] + ';' + word_info[1] + ';' + word_info[2]  + '\n')
				except:
					print f
			freeling.close()

#text_file = codecs.open('esl_587_freeling.txt', 'r', 'utf-8')
#text = text_file.read()
#for i in range(len(text)):
#	letter = text[i]
##	try:
#		text[i] = letter.decode('utf-8')
#	except:
#		text[i] = letter.encode('cp1251').decode('utf-8')
#freeling = codecs.open('esl_587_freeling.csv', 'w', 'utf-8')
#result_freeling = lemmatizer(text)
#print result_freeling
#for word_info in result_freeling:
#	try:
#		freeling.write(word_info[0] + ';' + word_info[1] + ';' + word_info[2] + '\n')
#	except:
#		print word_info[0]
#		freeling.write(word_info[0].decode('cp1251') + ';' + word_info[1].decode('cp1251') + word_info[2] + '\n')

#freeling.close()