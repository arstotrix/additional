import codecs, re, os
import subprocess as sp

def main():
    # Here we go!
    for root, dirs, files in os.walk('.'):
        for f in files:
            if f.endswith('.ann') and not f.endswith('_new.ann'):
                print f, root
                text, freeling = analyzing(f[:-4] + '.txt')
                coord = coordinates(text)
                freeling = matching(coord, freeling)
                writing(f, freeling)
                continue

def lemmatizer(x):
    lemmas = []
    tagged = sp.Popen([u'analyzer_client', u'40005'], stdin=sp.PIPE, stdout=sp.PIPE).communicate(x.encode('utf-8'))[0]
    tagged = tagged.strip().split('\n')
    #print tagged
    for word in tagged:
        word = word.split()
        if word:
        # and word[0] != ',' and word[0] != '.' and word[0] != '?' and word[0] != '!':
            lemmas.append(word[:-1])
    return lemmas

def analyzing(f):
##  This is Andrey's function, we're analyzing the text with Freeling
    text_file = codecs.open(f, 'r', 'utf-8')
    text = text_file.read()
    freeling = lemmatizer(text)
##    textf = codecs.open(f, 'r', 'utf-8')
##    text = textf.read()
##    freeling = []
##    freeling_file = codecs.open(f[:-4] + '.csv', 'r', 'utf-8')
##    for line in freeling_file:
##        freeling_line = line.split(';')
##        freeling.append(freeling_line)
##    freeling_file.close()
    return text, freeling

def coordinates(text):
    # Now we ought to find positions in the stand-off format for every word
    count = 0
    coordinates = []
    for index in range(len(text) - 1):
        if text[index] in ' \t\r\n' and text[index + 1] in ' \t\r\n':
            continue
        if index == 0 and text[index] not in ' \t\r\n':
            coordinate1 = 0
            for i in range(coordinate1, coordinate1 + 20):
                if text[i] in '/.,!?\'":;-() \t\r\n':
                    coordinate2 = i
                    break
        if text[index - 1] in '/\'"()-':
            coordinate1 = index
            for i in range(coordinate1, coordinate1 + 20):
                if text[i] in '/.,!?\'":;-() \t\r\n':
                    coordinate2 = i
                    break
        if text[index - 1] in '/.,!?\'":;-()' and text[index - 2] in '/.,!?\'":;-()' and text[index] not in '.,!?\'":;-() \t\r\n':
            coordinate1 = index
            for i in range(coordinate1, coordinate1 + 20):
                if text[i] in '/.,!?\'":;-() \t\r\n':
                    coordinate2 = i
                    break
        if text[index] in '/.,!?\'":;-() \t\r\n':
            if text[index] in '/.,!?\'":;-()':
                coordinate1 = index
                coordinate2 = index + 1
            else:
                coordinate1 = index + 1
                for i in range(coordinate1, coordinate1 + 20):
                    if text[i] in '/.,!?\'":;-() \t\r\n':
                        coordinate2 = i
                        break
        try:
            if text[index] in '/.,!?\'":;-() \t\r\n' or index == 0 or text[index - 1] in '/\'"()-.,;:?!':
                if coordinate1 != coordinate2:
                    coordinates.append([coordinate1, coordinate2])
        except:
            continue
        count += 1
    return coordinates

def matching(coordinates, freeling):
    verbs = ['are', 'is', 'need', 'did', 'had', 'has', 'would', 'should', 'do', 'does', 'have', 'were', 'was', 'could']
    for i in range(len(freeling)):
        try:
            m = re.search('^[^_]+_[^_%]+$', freeling[i][0], flags = re.U)
            n = re.search('[^%]+-[^%]+', freeling[i][0])
            l = re.search('[^_]+_[^_%]+_', freeling[i][0], flags = re.U)
            q = re.search('[^_]+_[^_%]+_[^_%]+_', freeling[i][0], flags = re.U)
            p = re.findall('_', freeling[i][0])
##            p = re.search('[^_]+_[^_%]+_[^_%]+_[^_%]+_', freeling[i][0], flags = re.U)
            z = re.search('[^-]*-[^-]*-[^-]*-', freeling[i][0])
            y = re.search('[^-]*-[^-]*-', freeling[i][0])
            x = re.search('\\d+[.,]\\d*(_%)?\\b', freeling[i][0], flags = re.U|re.I)
            if m != None:
                t = re.search('\\d+.*million', freeling[i][0], flags = re.U|re.I)
                if t != None:
                    # 2.4_million
                    coordinate1 = coordinates[i][0]
                    coordinate2 = coordinates[i + 3][1]
                    del coordinates[i:i + 3]
                elif ',' in freeling[i][0]:
                    # for 2,5_times
                    coordinate1 = coordinates[i][0]
                    coordinate2 = coordinates[i + 3][1]
                    del coordinates[i:i + 3]
                else:
                    if '.' in freeling[i][0]:
                        u = re.findall('\.', freeling[i][0])
                        t = len(u) + 2
                        # A._Huxley
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + t][1]
                        del coordinates[i:i + t]
                    else:
                        if '-' in freeling[i][0]:
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + 3][1]
                            del coordinates[i:i + 3]
                        else:
                            # for compound words, such as "for_example"
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + 1][1]
                            del coordinates[i + 1]
            elif freeling[i][0] == '\'\'':
                # ''
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 1][1]
                del coordinates[i:i + 1]
            elif freeling[i + 1][0] == '\'d':
                # we'd
                freeling[i][0] = freeling[i][0] + freeling[i + 1][0]
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 1][1]
                del coordinates[i:i + 1]
            elif freeling[i][0] == '...':
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                del coordinates[i:i + 2]
            elif '/' in freeling[i][0]:
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                del coordinates[i:i + 2]
            elif freeling[i][0] == 'woudn\'t':
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                del coordinates[i:i + 2]    
            elif freeling[i][0] == 'i.e.' or freeling[i][0] == 'e.g.' or freeling[i][0] == 'U.S.':
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 3][1]
                del coordinates[i:i + 3]
            elif freeling[i][0] == '2010_about_11':
                # Greatest facepalm
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1] - 1
                del coordinates[i:i + 1]
            elif freeling[i][0] == 'there' and freeling[i + 1][0] == '\'re':
                freeling[i][0] = freeling[i][0] + '\'re'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 1][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i]
            elif n != None:
                u = re.findall('_', freeling[i][0])
                if u != []:
                    t = len(u) + 2
                    if '%' in freeling[i][0]:
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + t - 1][1]
                        del coordinates[i:i + t - 1]
                    else:
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + t][1]
                        del coordinates[i:i + t]
                elif y != None:
                    if z != None:
                        # for those monstrous "40-year-aged-people" or so
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 6][1]
                        del coordinates[i:i + 6]
                    else:
                        # pour moins terrifiques '40-year-olds'
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 4][1]
                        del coordinates[i:i + 4]
                else:
                    # for two entities divided by '-'
                    if '\'s' in freeling[i][0]:
                        # for 's
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 4][1]
                        problem_coordinates = [coordinate1, coordinate2]
                        del coordinates[i:i + 4]
                    else:
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 2][1]
                        del coordinates[i]
                        del coordinates[i + 1]
                if '%' in freeling[i][0]:
                    # in case they are in fact percentage
                    if coordinates[i + 1][1] - coordinates[i + 1][0] == 1 and freeling[i + 1][0] not in '.,?!;:()':
                        freeling[i][0] = freeling[i][0][:-2] + ' ' + '%'
                        coordinate1 = coordinates[i][0] - 1
                        coordinate2 = coordinates[i + 1][1]
                        del coordinates[i]
            elif l != None:
                if q != None:
                    if p != []:
                        if '.' in freeling[i][0] or '\'' in freeling[i][0]:
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + 6][1]
                            del coordinates[i:i + 6]
                        else:
                            t = len(p)
                            # for x_x_x_x_x
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + t][1]
                            del coordinates[i:i + t]
                    else:
                        if '.' in freeling[i][0] or '\'' in freeling[i][0]:
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + 5][1]
                            del coordinates[i:i + 5]
                        else:
                            # for "on_the_other_hand"
                            coordinate1 = coordinates[i][0]
                            coordinate2 = coordinates[i + 3][1]
                            del coordinates[i:i + 3]
                else:
                    if '.' in freeling[i][0] or '\'' in freeling[i][0]:
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 3][1]
                        del coordinates[i:i+2]
                    else:
                        # for another monstrous thing like "Second_World_War"
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 2][1]
                        del coordinates[i]
                        del coordinates[i + 1]
            elif x != None:
                if '%' in freeling[i][0]:
                    if freeling[i + 1][0] == ')' or freeling[i + 1][0] == ',' or freeling[i + 1][0] == '.':
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 3][1] - 1
                        del coordinates[i:i + 2]
                    else:
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 3][0] - 1
                        del coordinates[i:i + 2]
                else:
                    r = re.search('\\d+[.,][^0]*0+', freeling[i][0], flags = re.U|re.I)
                    q = re.search('\\d+[.,]\\d+[.,]\\d+', freeling[i][0], flags = re.U|re.I)
                    if q != None:
                        # 5.12.2011
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 3][1] + 3
                        del coordinates[i:i + 4]
                    elif r != None:
                        # for numbers with many zeros
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 2][1] + 3
                        del coordinates[i]
                        del coordinates[i + 1]
                    else:
                        # for numbers with , or . as markers of division
                        coordinate1 = coordinates[i][0]
                        coordinate2 = coordinates[i + 2][1] + 1
                        del coordinates[i:i + 2]
            elif (freeling[i][0] == 'let' or freeling[i][0] == 'Let') and freeling[i + 1][0] == 'us' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # let's
                freeling [i][0] = freeling[i][0] + '\'s'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif (freeling[i][0] == 'I' or freeling[i][0] == 'i') and freeling[i + 1][0] == 'am' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # I'm
                freeling [i][0] = freeling[i][0] + '\'m'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i + 1][0] == 'have' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # I've
                freeling [i][0] = freeling[i][0] + '\'ve'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i + 1][0] == 'will' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # we'll
                freeling [i][0] = freeling[i][0] + '\'ll'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i][0] == 'can' and freeling[i + 1][0] == 'not' and coordinates[i][1] - coordinates[i][0] == 6:
                # cannot
                freeling[i][0] = freeling[i + 1][0] = 'cannot'
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i][1]
                problem_coordinates = [coordinate1, coordinate2]
                coordinates[i:i] = [problem_coordinates]
            elif freeling[i][0] == '2010.The':
                # Facepalm #1
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinate1 + 8
                del coordinates[i]
            elif '%' in freeling[i][0] and (coordinates[i + 1][1] - coordinates[i + 1][0] == 1 and freeling[i + 1][0] not in '.,?!;:()'):
                # for "100 %"
                freeling[i][0] = freeling[i][0][:-2] + ' ' + '%'
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 1][1]
                del coordinates[i]
            elif freeling[i][0].endswith('.') and len(freeling[i][0]) > 1:
                # Facepalm #2
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 1][1]
                del coordinates[i + 1]
            elif (freeling[i][0] == 'there' or freeling[i][0] == 'There' or freeling[i][0] == 'They' or freeling[i][0] == 'they') and coordinates[i + 1][1] - coordinates[i + 1][0] == 1 and freeling[i + 1][0] not in '.,?!;:()-' and (freeling[i + 1][0] == 'is' or freeling[i + 1][0] == 'are'):
                # There's, there're
                if freeling[i + 1][0] == 'is':
                    freeling[i][0] = freeling[i][0] + '\'s'
                elif freeling[i + 1][0] == 'are':
                    freeling[i][0] = freeling[i][0] + '\'re'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i][0] == 'will' and freeling[i + 1][0] == 'not' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # won't
                freeling [i][0] = 'won\'t'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i][0] == 'can' and freeling[i + 1][0] == 'not' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # can't
                freeling [i][0] = 'can\'t'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i][0] in verbs and freeling[i + 1][0] == 'not' and coordinates[i + 1][1] - coordinates[i + 1][0] == 1:
                # for n't
                freeling[i][0] = freeling[i][0] + 'n\'t'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            elif freeling[i + 1][0] == '\'s':
                # for 's possessive!
                freeling[i][0] = freeling[i][0] + '\'s'
                freeling[i + 1][0] = freeling[i][0]
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i + 2][1]
                problem_coordinates = [coordinate1, coordinate2]
                del coordinates[i + 1]
            else:
                # These cases are great relief
                coordinate1 = coordinates[i][0]
                coordinate2 = coordinates[i][1]
            if freeling[i][0][-3:] == '\'ve' or freeling[i][0][-2:] == '\'m' or freeling[i][0][-2:] == '\'s' or (freeling[i][0][-3:] == 'n\'t' and freeling[i][0] != 'woudn\'t') or freeling[i][0][-3:] == '\'re' or freeling[i][0][-3:] == '\'ll' or (freeling[i][0] == 'not' and coordinates[i - 1][1] - coordinates[i - 1][0] == 6):
                # when we encounter 'not' or the possessive ending
                try:
                    coordinate1 = problem_coordinates[0]
                    coordinate2 = problem_coordinates[1]
                except:
                    print freeling[i][0], coordinates[i - 1]
                    print 'Smth\'s wrong with the contracted forms!'          
            freeling[i].append(str(coordinate1) + ' ' + str(coordinate2))
        except IndexError:
            # for the last word
            freeling[i].append(str(coordinates[-1][0]) + ' ' + str(coordinates[-1][1]))
    return freeling

def writing(f, freeling):
    old_ann_file = codecs.open(f, 'r', 'utf-8')
    mistakes = []
    # We should rewrite only the "mistakes" annotations, so we want to get rid of the previous "pos" annotations
    for line in old_ann_file:
        m = re.search('T\\d+\\tpos', line)
        l = re.search('lemma = ', line)
        if m == None and l == None:
            mistakes.append(line)
    old_ann_file.close()
    ann_file = codecs.open(f, 'w', 'utf-8')
    for mistake in mistakes:
        ann_file.write(mistake)
    ann_file.close()
    ann_file = codecs.open(f, 'r', 'utf-8')
    ann = ann_file.read()
##    last_T = re.findall('.*(?:\n)?T(\\d+)', ann, flags = re.U)
    last_T = max(re.findall('\nT([0-9]+)', ann, flags = re.U))
    last_x = max(re.findall('.*(?:\n)?#(\\d+)', ann, flags = re.U))
    ann_file.close()
    ann_file = codecs.open(f, 'a', 'utf-8')
    if last_T == []:
        t = 1
    else:
        t = int(last_T[-1]) + 1
    if last_x == []:
        x = 1
    else:
        x = int(last_x[-1]) + 1
    for word in freeling:
        word[0] = re.sub('_%', '%', word[0])
        word[0] = re.sub('_', ' ', word[0])
        try:
            word[2] = re.sub('\$', '2', word[2])
            ann_file.write('T' + str(t) + '\tpos_' + word[2] + ' ' + word[3] + '\t' + word[0] + '\n' +\
                      '#' + str(x) + '\tAnnotatorNotes T' + str(t) + '\t' + 'lemma = \'' +\
                      word[1] + '\'\n')
            x += 1
            t += 1
        except:
            print word
    ann_file.close()

if __name__ == '__main__':
    main()
