# coding: utf-8
# author: liza
from lemmatizer import lemmatizer
import codecs, sys

def morpho(tkn, last_T, last_x):
    t = last_T + 1
    x = last_x + 1
    tkn = codecs.open(tkn, 'r', 'utf-8')
    spans = []
    tokens = ''
    for line in tkn.readlines():
	tokens += line.split('\t')[1] + ' '
	spans.append(line.strip().split('\t')[2])
    morpho_ann = u''
    lemmas = lemmatizer(tokens.encode('utf-8'))
    for l in range(len(lemmas)):
	morpho_ann += 'T' + str(t) + '\tpos_' + lemmas[l][2].decode('utf-8') + ' ' + spans[l] + '\t' + '\n' + '#' + str(x) +\
		  '\tAnnotatorNotes T' + str(t) + '\t' + 'lemma = \'' + lemmas[l][1].decode('utf-8') + '\'\n'
	t += 1
	x += 1
    return morpho_ann

#tkn_path = sys.argv[1]
#ann_file = codecs.open('anewannfile.ann', 'a', 'utf-8')
#morpho_stream = morpho(tkn_path)
#ann_file.write(morpho_stream)
#ann_file.close()