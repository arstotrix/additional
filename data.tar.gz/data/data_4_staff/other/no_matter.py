# coding: utf-8
import re
import sys, codecs
from lemmatizer import lemmatizer
from morpho_ann import morpho

def token(t):
    from lemmatizer import lemmatizer
    dic = {'will': '\'ll', 'are': '\'re', 'am': '\'m', 'is': '\'s', 'not': 'n\'t'}
    expr = []
    tkn = u''
    for c in dic.values():
        if c in t:
	    expr += re.findall('\\s+([^\\s]*)' + c, t, flags=re.U)
    n = 0
    lemmas = lemmatizer(t)
    for l in range(len(lemmas)):
	w = lemmas[l][0]
	if w in dic.keys() and lemmas[l - 1][0] in expr:
	    w = dic[w]#.replace('\'', u'’')
	try:
	    span = (t.index(w), t.index(w) + len(w.decode('utf-8')))
	except ValueError:
	    if '_' in w:
		w = w.replace('_', ' ')
		try:
		    span = (t.index(w), t.index(w) + len(w.decode('utf-8')))
		except ValueError:
		    w = w.replace(' ', '')
		    try:
			span = (t.index(w), t.index(w) + len(w.decode('utf-8')))
		    except:
			print w
	    else:
		print w
	t = t[:span[0]] + ' '* len(w) +  t[span[1]:]
	tkn += str(n) + '\t' + w.decode('utf-8') + '\t' + str(span[0]) + ' ' + str(span[1]) + '\n'
	n += 1
    return tkn

#text = sys.argv[1]
#with open('atknfile.tkn', 'w') as tkn_file:
#    tkn_stream = token(text)
#    tkn_file.write(tkn_stream.encode('utf-8'))
#    tkn_file.close()
d = sys.argv[1]
txt = codecs.open(d, 'r', 'utf-8-sig').read()
tkn_stream = token(txt.encode('utf-8'))
#print tkn_stream
tkn_file = codecs.open(d[:-4] + '.tkn', 'w', 'utf-8')
tkn_file.write(tkn_stream)
tkn_file.close()
ann_file = codecs.open(d[:-4] + '.ann', 'r', 'utf-8').read()
last_T = max([int(x) for x in re.findall('\nT([0-9]+)', ann_file, flags = re.U)])
last_x = max([int(x) for x in re.findall('.*(?:\n)?#(\\d+)', ann_file, flags = re.U)])
ann_file = codecs.open(d[:-4] + '.ann', 'a', 'utf-8')
ann_file.write(morpho(d[:-4] + '.tkn', last_T, last_x))
ann_file.close()

